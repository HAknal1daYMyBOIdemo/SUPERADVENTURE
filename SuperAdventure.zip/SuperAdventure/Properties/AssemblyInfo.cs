﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("SuperAdventure")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SuperAdventure")]
[assembly: AssemblyCopyright("SUGMA")]
[assembly: AssemblyTrademark("SSSSS")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

////////// CODE BY AIDAN RIP BOZO THIS IS MINE YONK ////////////////

[assembly: AssemblyVersion("10000")]
[assembly: AssemblyFileVersion("10000")]
